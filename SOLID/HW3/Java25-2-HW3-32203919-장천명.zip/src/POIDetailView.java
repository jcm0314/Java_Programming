import java.util.List;

/**
 * POIDetailView 클래스
 * 근접 이벤트를 받아서 사용자 인터페이스에 표시하는 클래스
 * ProximityObserver 인터페이스를 구현하여 Observer 패턴의 Observer 역할 수행
 */
public class POIDetailView implements ProximityObserver{

    /**
     * 가장 가까운 POI 목록이 변경되었을 때 호출되는 메서드
     * Top-K POI 목록을 순위와 함께 화면에 표시
     * @param nearest 거리순으로 정렬된 가장 가까운 POI 목록
     */
    @Override
    public void onNearestChanged(List<POI> nearest) {
        System.out.println("[UI] Top-K nearest updated:");
        for (int i = 0; i < nearest.size(); i++) {
            POI poi = nearest.get(i);
            System.out.printf(" #%d %s @ %s%n", (i+1), poi.name, poi.location);
        }
    }

    /**
     * 근접 반경에 진입했을 때 호출되는 메서드
     * 사용자에게 근접 진입 알림을 표시
     * @param poi 진입한 POI 객체
     * @param distance 현재 위치에서 POI까지의 거리 (미터)
     */
    @Override
    public void onEnter(POI poi, double distance) {
        System.out.printf("[UI] ENTER range: %s (%.1fm)%n", poi.name, distance);
    }

    /**
     * 근접 반경에서 이탈했을 때 호출되는 메서드
     * 사용자에게 근접 이탈 알림을 표시
     * @param poi 이탈한 POI 객체
     * @param distance 현재 위치에서 POI까지의 거리 (미터)
     */
    @Override
    public void onExit(POI poi, double distance) {
        System.out.printf("[UI] EXIT range: %s (%.1fm)%n", poi.name, distance);
    }
}
